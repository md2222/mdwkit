/*\
title: $:/core/modules/savers/mdwkit.js
type: application/javascript
module-type: saver
\*/
(function(){

/*jslint node: true, browser: true */
/*global $tw: false */
"use strict";

/*
Select the appropriate saver module and set it up
*/
var mdwkitSaver = function(wiki) {
};

var saveCount = 0;

mdwkitSaver.prototype.save = function(text, method, callback, options) {
    options = options || {};
    // Get the current filename
    var filename = document.location.href.replace("file://", "");
    if(!filename) {
        filename = "tiddlywiki.html";
    }
    console.log("filename=" + filename);
    //console.log("saveCount=" + saveCount);

    var query = "savedata?file=" + filename;
    // backup for session only
    if (saveCount == 0)
        query += "&mode=rn";  

    var resp = jsCoreRequest(query, text);
    console.log(resp);
    saveCount++;

    var p = resp.indexOf("\r\n\r\n");  // header end
    var header = JSON.parse(resp.substr(0, p));

    if (!p || !header.errCode)  
        callback("mdwkit saver: Response error: Header bad format.\n");
    else if (header.errCode != "0")
        callback("mdwkit saver: " + header.errText);
    else
        // Callback that we succeeded
        callback(null);

    return true;
};

/*
Information about this saver
*/
mdwkitSaver.prototype.info = {
	name: "mdwkit",
	priority: 1000
};

Object.defineProperty(mdwkitSaver.prototype.info, "capabilities", {
	get: function() {
		var capabilities = ["save", "download"];
		if(($tw.wiki.getTextReference("$:/config/mdwkitSaver/AutoSave") || "").toLowerCase() === "yes") {
			capabilities.push("autosave");
		}
		return capabilities;
	}
});

/*
Static method that returns true if this saver is capable of working
*/
exports.canSave = function(wiki) {
	return typeof jsCoreRequest === 'function';
};

/*
Create an instance of this saver
*/
exports.create = function(wiki) {
	return new mdwkitSaver(wiki);
};

})();
